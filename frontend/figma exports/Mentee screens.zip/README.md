
  # Mentorship Platform for KPDF

  This is a code bundle for Mentorship Platform for KPDF. The original project is available at https://www.figma.com/design/WDVOMRD8sDRRrXJlgdtbrf/Mentorship-Platform-for-KPDF.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  